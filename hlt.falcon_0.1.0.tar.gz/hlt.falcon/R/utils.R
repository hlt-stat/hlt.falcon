utils::globalVariables(c(".data", "TRTEMFL", "USUBJID", "V1", "analyze", "append_topleft", "build_table", "count_patients_with_event", "in_rows", "prune_table", "split_cols_by_arm"))
